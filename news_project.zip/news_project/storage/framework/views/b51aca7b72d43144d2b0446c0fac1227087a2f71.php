<!-- resources/views/admin/articles/import.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Import Articles</h2>

        <form action="<?php echo e(route('admin.articles.import')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="file">Choose file to import:</label>
                <input type="file" name="file" accept=".json, .xlsx, .xls" class="form-control-file">
            </div>

            <button type="submit" class="btn btn-primary">Import</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_project\resources\views/admin/articles/import.blade.php ENDPATH**/ ?>
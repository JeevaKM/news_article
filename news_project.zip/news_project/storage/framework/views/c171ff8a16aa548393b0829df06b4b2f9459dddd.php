<!-- resources/views/admin/articles/index.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Admin Dashboard</h2>

        <h3>Articles</h3>
        <a href="<?php echo e(route('admin.articles.import')); ?>" class="btn btn-primary">Import Articles</a>

        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Content</th>
                    <th>Date</th>
                    <th>Source</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($article->title); ?></td>
                        <td><?php echo e($article->content); ?></td>
                        <td><?php echo e($article->date); ?></td>
                        <td><?php echo e($article->source); ?></td>
                        <td>
                            <form action="<?php echo e(route('admin.articles.destroy', $article)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\news_project\resources\views/admin/articles/index.blade.php ENDPATH**/ ?>
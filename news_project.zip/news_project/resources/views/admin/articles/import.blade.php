<!-- resources/views/admin/articles/import.blade.php -->

@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Import Articles</h2>

        <form action="{{ route('admin.articles.import') }}" method="post" enctype="multipart/form-data">
            @csrf

            <div class="form-group">
                <label for="file">Choose file to import:</label>
                <input type="file" name="file" accept=".json, .xlsx, .xls" class="form-control-file">
            </div>

            <button type="submit" class="btn btn-primary">Import</button>
        </form>
    </div>
@endsection

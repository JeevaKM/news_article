<!-- resources/views/admin/articles/index.blade.php -->

@extends('layouts.app')

@section('content')
    <div class="container">
        <h2>Admin Dashboard</h2>

        <h3>Articles</h3>
        <a href="{{ route('admin.articles.import') }}" class="btn btn-primary">Import Articles</a>

        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Content</th>
                    <th>Date</th>
                    <th>Source</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($articles as $article)
                    <tr>
                        <td>{{ $article->title }}</td>
                        <td>{{ $article->content }}</td>
                        <td>{{ $article->date }}</td>
                        <td>{{ $article->source }}</td>
                        <td>
                            <form action="{{ route('admin.articles.destroy', $article) }}" method="post">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection

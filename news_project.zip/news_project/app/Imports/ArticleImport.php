<?php
// app/Imports/ArticleImport.php

namespace App\Imports;

use App\Models\Article;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class ArticleImport implements ToModel, WithHeadingRow
{
    public function model(array $row)
    {
        return new Article([
            'title'   => $row['title'],
            'content' => $row['content'],
            'date'    => $row['date'],
            'source'  => $row['source'],
            // Add other attributes as needed
        ]);
    }
}

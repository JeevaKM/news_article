<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;

class Article extends Model
{
    use HasFactory;
    protected $fillable = ['title', 'content', 'date', 'source'];

    // public function isBookmarked()
    // {
    //     $user = Auth::user();

    //     if ($user) {
    //         return $this->bookmarks()->where('user_id', $user->id)->exists();
    //     }

    //     return false;
    // }

    public function bookmarks()
    {
        return $this->hasMany(Bookmark::class);
    }
}

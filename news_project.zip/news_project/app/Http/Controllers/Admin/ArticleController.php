<?php

// app/Http/Controllers/Admin/ArticleController.php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Article;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\ArticleImport;





class ArticleController extends Controller
{
    public function index()
    {
        $articles = Article::all();
        return view('admin.articles.index', compact('articles'));
    }

    public function show()
    {
        return view('admin.articles.import');
    }

    public function import(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:json,xlsx,xls|max:10240',
        ]);

        $file = $request->file('file');
        $extension = $file->getClientOriginalExtension();

        if ($extension == 'json') {
            $this->importJson($file);
        } elseif (in_array($extension, ['xlsx', 'xls'])) {
            $this->importExcel($file);
        }

        return redirect()->route('admin.articles.index')->with('success', 'Articles imported successfully');
    }

    private function importJson($file)
    {
        $contents = json_decode(file_get_contents($file), true);

        foreach ($contents as $articleData) {
            Article::create($articleData);
        }
    }

    private function importExcel($file)
    {
        Excel::import(new ArticleImport, $file);
    }

    public function destroy(Article $article)
    {
      
        $article->delete();
        return redirect()->route('admin.articles.index')->with('success', 'Article deleted successfully');
    }
}


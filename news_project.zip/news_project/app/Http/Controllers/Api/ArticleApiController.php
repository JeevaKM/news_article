<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Article;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Validator;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
 


class ArticleApiController extends Controller
{
    public $successStatus = 200;
/** 
     * login api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    use AuthenticatesUsers;

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
       
    }

    public function index($userId)
{
    $articles = Article::with([
        'bookmarks' => function ($query) use ($userId) {
            
            $query->where('user_id', $userId);
        },
    ])->get();

    return response()->json($articles);
}

    protected function authenticated(Request $request, $user)
    {
        $access_token=['token' =>$user->createToken('Token Name')->accessToken,'name'=>$user->id];
        return response()->json($access_token);
    }

    public function bookmark(Request $request, Article $article)
{
 
    $userId = $request->input('user_id');
   
    
    if ($userId) {
       
        $user = User::find($userId);
      
        
        $user->articles()->syncWithoutDetaching([$article->id]);

        return response()->json(['message' => 'Article bookmarked successfully']);
    }

    // If no user ID is provided, return an error response
    return response()->json(['error' => 'User ID is required for bookmarking'], 400);
}

  


    
   
    
}

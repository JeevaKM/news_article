<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\ArticleController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

// routes/web.php



Route::middleware(['auth', 'admin'])->group(function () {
    Route::resource('admin/articles', ArticleController::class);
    Route::get('admin/articles/import', [ArticleController::class, 'showImportForm'])->name('admin.articles.import.form');
    Route::post('admin/articles/import', [ArticleController::class, 'import'])->name('admin.articles.import');

});
Route::middleware(['auth', 'admin'])->delete('admin/articles/{article}',[ArticleController::class, 'destroy'])->name('admin.articles.destroy'); 
Route::middleware(['auth', 'admin'])->get('admin/articles', [ArticleController::class, 'index'])->name('admin.articles.index');



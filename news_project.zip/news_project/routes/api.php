<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ArticleApiController;
use Laravel\Passport\Http\Controllers\AccessTokenController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

// routes/api.php


Route::post('/login', [ArticleApiController::class,'login']);
Route::post('/register', [ArticleApiController::class,'register']);
// Route::get('articles', [ArticleApiController::class, 'index']);
Route::get('/articles/{user}', [ArticleApiController::class, 'index']);
Route::post('/articles/{article}/bookmark', [ArticleApiController::class, 'bookmark']);
//Route::middleware('auth:api')->get('articles', [ArticleApiController::class, 'index']);


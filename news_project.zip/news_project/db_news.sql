-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:8111
-- Generation Time: Dec 28, 2023 at 11:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_news`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `date` date NOT NULL,
  `source` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `content`, `date`, `source`, `created_at`, `updated_at`) VALUES
(1, 'Sample Title 1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', '2023-01-01', 'Sample Source 1', '2023-12-26 02:59:06', '2023-12-26 02:59:06'),
(2, 'Sample Title 2', 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', '2023-01-02', 'Sample Source 2', '2023-12-26 02:59:06', '2023-12-26 02:59:06'),
(3, 'Sample Title 3', 'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.', '2023-01-03', 'Sample Source 3', '2023-12-26 02:59:06', '2023-12-26 02:59:06');

-- --------------------------------------------------------

--
-- Table structure for table `bookmarks`
--

CREATE TABLE `bookmarks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `article_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bookmarks`
--

INSERT INTO `bookmarks` (`id`, `user_id`, `article_id`, `created_at`, `updated_at`) VALUES
(3, 1, 2, '2023-12-26 06:49:15', '2023-12-26 06:49:15'),
(4, 1, 3, '2023-12-26 07:14:15', '2023-12-26 07:14:15'),
(5, 1, 1, '2023-12-28 01:18:43', '2023-12-28 01:18:43'),
(6, 5, 1, '2023-12-28 01:38:28', '2023-12-28 01:38:28');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_12_21_124744_create_articles_table', 1),
(6, '2023_12_21_142143_add_is_admin_to_users_table', 2),
(7, '2023_12_22_034001_create_bookmarks_table', 3),
(8, '2016_06_01_000001_create_oauth_auth_codes_table', 4),
(9, '2016_06_01_000002_create_oauth_access_tokens_table', 4),
(10, '2016_06_01_000003_create_oauth_refresh_tokens_table', 4),
(11, '2016_06_01_000004_create_oauth_clients_table', 4),
(12, '2016_06_01_000005_create_oauth_personal_access_clients_table', 4);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE `oauth_access_tokens` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('04957eb98b2a023d69c22900b9e646ba04141a12e39df6de8951ee724c16ca77cdfc99414dcee65a', 1, 3, NULL, '[]', 0, '2023-12-22 02:37:10', '2023-12-22 02:37:10', '2024-12-22 08:07:10'),
('0fbd7389b37b13fc87848dbc64b8101579f7151aecfca724631c826d239dfb136b5c00c722b1a55a', 1, 1, 'Token Name', '[]', 0, '2023-12-25 07:25:15', '2023-12-25 07:25:17', '2024-12-25 12:55:15'),
('1bd7c18eb737f6443cde962906bfc1d363861f21a199079f6d563bd408113ecdffc05bfacbd3d92a', 5, 1, 'Token Name', '[]', 0, '2023-12-25 08:34:51', '2023-12-25 08:34:52', '2024-12-25 14:04:51'),
('28ee5e4ad26e2bed40d701afa5875146a61e0fad002db0b8b59bbc9f8b623a0ae7ef797136ca59da', 5, 1, 'Token Name', '[]', 0, '2023-12-24 11:10:03', '2023-12-24 11:10:04', '2024-12-24 16:40:03'),
('39836d2f09a6c070ce6f65da6837539fcf34e7e6124b504a05e63d87195a0fc458871fee88011a9e', 1, 1, 'Token Name', '[]', 0, '2023-12-25 07:59:19', '2023-12-25 07:59:20', '2024-12-25 13:29:19'),
('4334408b187503628b5a28db9492620f2f62f7dd72e1e41f361d8f96d6ebb63ec3b01d81f730b19e', 5, 1, 'Token Name', '[]', 0, '2023-12-24 11:03:12', '2023-12-24 11:03:12', '2024-12-24 16:33:12'),
('6075b7b341bdc4694c8de3e09f8101d8a15af6482899e33ceafd41e6e7abb38a3bdb7f2befdcad8a', 1, 1, 'Token Name', '[]', 0, '2023-12-24 11:00:15', '2023-12-24 11:00:16', '2024-12-24 16:30:15'),
('73972afc361ef64609c0b8c71eb20f34ef7140df726134d5bf8450d5edecbdba3f174bdebba63517', 1, 1, 'Token Name', '[]', 0, '2023-12-25 08:07:06', '2023-12-25 08:07:06', '2024-12-25 13:37:06'),
('8ca39bd7cd2997468953c9183c52aa7dcbb94548f03cc8fa2368e4e0175c6c297496db99f7104d49', 5, 1, 'Token Name', '[]', 0, '2023-12-25 09:19:25', '2023-12-25 09:19:26', '2024-12-25 14:49:25'),
('9a704dda6f55b9cd10096fb248e38ac61b67081c3378825e38c09604fea15cadb9a41be28642eb5b', 5, 1, 'Token Name', '[]', 0, '2023-12-24 23:45:39', '2023-12-24 23:45:39', '2024-12-25 05:15:39'),
('ac48a37ab4453a8d162197bb6b516ac57d04b692b0998ac3c1ddbd187824161475b26bbcb2553848', 2, 1, 'MyApp', '[]', 0, '2023-12-24 09:26:42', '2023-12-24 09:26:43', '2024-12-24 14:56:42'),
('ca8cb74a9b5f0c6e89b1db8280f846759d54b32c4889b82b4784efa9d9ab62e8222af3b209e4c49e', 5, 1, 'Token Name', '[]', 0, '2023-12-24 11:11:09', '2023-12-24 11:11:09', '2024-12-24 16:41:09'),
('cdc4436de2e66c665839c9cbda693b72247862be261f93cca1a043fd69d4aaf405b0c403139d812a', 5, 1, 'Token Name', '[]', 0, '2023-12-24 23:37:26', '2023-12-24 23:37:26', '2024-12-25 05:07:26'),
('dec51e52a0b377ed266eb9d92c490315f3d11ce188b4a77153162d35343500613cc0440eb94ecc65', 5, 1, 'Token Name', '[]', 0, '2023-12-24 11:06:12', '2023-12-24 11:06:12', '2024-12-24 16:36:12'),
('e1278cf0097cff8ec70e2a21830acb8f163eb860b5cfb3db6cd0889cfa4798f4bb9ac2cc784a6aee', 5, 1, 'Token Name', '[]', 0, '2023-12-25 08:28:13', '2023-12-25 08:28:13', '2024-12-25 13:58:13'),
('ea9876c98b06bf0f3ecb8b5b16fe450e7010ce97ef566272e74c4e5f9813859b692d401231bec1ce', 5, 1, 'Token Name', '[]', 0, '2023-12-25 08:25:08', '2023-12-25 08:25:08', '2024-12-25 13:55:08'),
('f9fcdd5eaab0559d3fd6a33aa0dd9ab3e91ffda8629dd52f08c729151e08787524c418f79e38adba', 5, 1, 'Token Name', '[]', 0, '2023-12-25 08:09:29', '2023-12-25 08:09:29', '2024-12-25 13:39:29');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE `oauth_auth_codes` (
  `id` varchar(100) NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `secret` varchar(100) DEFAULT NULL,
  `provider` varchar(255) DEFAULT NULL,
  `redirect` text NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'hLOb6P7wXXQytfH8nVoMxWxHitiQRptJWzjpEGOM', NULL, 'http://localhost', 1, 0, 0, '2023-12-21 23:22:12', '2023-12-21 23:22:12'),
(2, NULL, 'Laravel Password Grant Client', 'npf1asodFKPM2eWI3ndgTGVgfYCvj9W8JLMoMnNx', 'users', 'http://localhost', 0, 1, 0, '2023-12-21 23:22:12', '2023-12-21 23:22:12'),
(3, NULL, 'MyApp Password Grant Client', 'tOLOpE5cOU07X7oR2Y7YpO2Sh4pVQFefO9A8JnlY', 'users', 'http://localhost', 0, 1, 0, '2023-12-22 00:38:34', '2023-12-22 00:38:34');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2023-12-21 23:22:12', '2023-12-21 23:22:12');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE `oauth_refresh_tokens` (
  `id` varchar(100) NOT NULL,
  `access_token_id` varchar(100) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_refresh_tokens`
--

INSERT INTO `oauth_refresh_tokens` (`id`, `access_token_id`, `revoked`, `expires_at`) VALUES
('0cd099f17356573cccfff0b0cf1ba6a9377251eea59bed978338c4729a68a07aee073372a049c172', '04957eb98b2a023d69c22900b9e646ba04141a12e39df6de8951ee724c16ca77cdfc99414dcee65a', 0, '2024-12-22 08:07:11');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `expires_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 2, 'MyApp', 'b84139b54d4016d8363a6ea25220afbde90b0e7b0875037fe88590c088907de1', '[\"*\"]', NULL, NULL, '2023-12-24 09:10:06', '2023-12-24 09:10:06'),
(2, 'App\\Models\\User', 5, 'MyApp', '63f44f3f69c08b4b45c677b4c032fb74decac73ad0a7d1cc3f4a823a6949681b', '[\"*\"]', NULL, NULL, '2023-12-24 09:19:47', '2023-12-24 09:19:47');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `is_admin`) VALUES
(1, 'admin', 'admin@test.com', NULL, '$2y$10$VYoDeX/rBkJ5Hsk0K1LBuuLuyKH3g8XGDiOBCnJMQ39z.yKR1iF46', NULL, '2023-12-21 07:49:48', '2023-12-21 07:49:48', 1),
(5, 'myuser1', 'myuser1@test.com', NULL, '$2y$10$HIV4j9CWC9er3wp8kuvIcubpBmWOJ3X4cksUY.NTpeXNCxMe36Ptq', NULL, '2023-12-24 09:19:47', '2023-12-24 09:19:47', 0),
(6, 'user', 'user@test.com', NULL, '$2y$10$In0GGab4UNVhWb9gPy5H7eg63jnSiK8MMi62H9AMXg9GKVJx5o0kq', NULL, '2023-12-28 01:20:29', '2023-12-28 01:20:29', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookmarks`
--
ALTER TABLE `bookmarks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bookmarks_user_id_foreign` (`user_id`),
  ADD KEY `bookmarks_article_id_foreign` (`article_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_access_tokens`
--
ALTER TABLE `oauth_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_access_tokens_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_auth_codes`
--
ALTER TABLE `oauth_auth_codes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_auth_codes_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_clients_user_id_index` (`user_id`);

--
-- Indexes for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oauth_refresh_tokens`
--
ALTER TABLE `oauth_refresh_tokens`
  ADD PRIMARY KEY (`id`),
  ADD KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bookmarks`
--
ALTER TABLE `bookmarks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `oauth_clients`
--
ALTER TABLE `oauth_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `oauth_personal_access_clients`
--
ALTER TABLE `oauth_personal_access_clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `bookmarks`
--
ALTER TABLE `bookmarks`
  ADD CONSTRAINT `bookmarks_article_id_foreign` FOREIGN KEY (`article_id`) REFERENCES `articles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bookmarks_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
